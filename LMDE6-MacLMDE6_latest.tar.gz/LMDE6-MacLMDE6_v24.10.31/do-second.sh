#!/bin/bash
# My first attempt at bash scripting.
#
# This script will decorate your desktop environment into looking like and function similar to a MacOS computer.
#
# Enjoy!
# -Joseph
#
# olddognewlinux@gmail.com
#
	if [ "$XDG_CURRENT_DESKTOP" = "XFCE" ]; then
 clear
echo
echo "   This final step will take only a few seconds to complete."
echo
echo
read -p "   Press Enter to continue with the installation, or Ctrl-Z to abort..."
echo
echo
#
 clear
echo
echo "   Putting things where they belong and applying settings... please wait a few seconds."
echo
 sleep 4
#
#
cp -rv .config ~/ 
cp -rv .icons ~/
cp -rv .themes ~/ 
cp -rv .local ~/ 
#
# Tweaking settings...
#
xfconf-query -c xsettings -pn /Net/ThemeName -t string -s MacOS_Theme 
xfconf-query -c xsettings -pn /Net/IconThemeName -t string -s MacOS_Icons 
xfconf-query -c xsettings -pn /Gtk/CursorThemeName -t string -s MacOS_Cursor 
xfconf-query -c xsettings -pn /Gtk/DecorationLayout -t string -s close,minimize,maximize: 
xfconf-query -c xsettings -pn /Gtk/FontName -t string -s 'Sans 11'
xfconf-query -c xsettings -pn /Gtk/MonospaceFontName -t string -s 'Monospace 11' 
xfce4-panel-profiles load .local/share/xfce4-panel-profiles/MyPanelProfile.tar.bz2 
wait
xfconf-query -c xfce4-panel -pn /plugins/plugin-1/digital-time-font -t string -s Sans 10 
xfconf-query -c xfce4-panel -pn /plugins/plugin-13/digital-date-font -t string -s Sans 10 
xfconf-query -c xfce4-panel -pn /plugins/plugin-2/plugins/plugin-2/bold-application-name -t bool -s true 
xfconf-query -c xfce4-panel -pn /plugins/plugin-8/square-icons -t bool -s true
xfconf-query -c xfce4-panel -pn /plugins/plugin-8/icon-size -t int -s '0' 
xfconf-query -c xfwm4 -pn /general/theme -t string -s MacOS_WM
xfconf-query -c xfwm4 -pn /general/button_layout -t string -s "CHM|" 
xfconf-query -c xfwm4 -pn /general/show_dock_shadow -t bool -s false 
xfconf-query -c xfwm4 -pn /general/placement_mode -t string -s center 
xfconf-query -c xfwm4 -pn /general/placement_ratio -t int -s 100 
xfconf-query -c xfwm4 -pn /general/move_opacity -t int -s 80 
xfconf-query -c xfwm4 -pn /general/workspace_count -t int -s 1
xfconf-query -c xfwm4 -pn /general/title_font -t string -s 'Sans Bold 12'
xfconf-query -c xfce4-settings-manager -pn /last/window-height -t int -s 700 
xfconf-query -c xfce4-settings-manager -pn /last/window-width -t int -s 975 
xfconf-query -c xfce4-desktop -pn /desktop-icons/file-icons/show-filesystem -t bool -s true 
xfconf-query -c xfce4-desktop -pn /desktop-icons/file-icons/show-home -t bool -s true 
xfconf-query -c xfce4-desktop -pn /desktop-icons/file-icons/show-removable -t bool -s true 
xfconf-query -c xfce4-desktop -pn /desktop-icons/file-icons/show-trash -t bool -s true 
xfconf-query -c xfce4-desktop -pn /desktop-icons/use-custom-font-size -t bool -s true 
xfconf-query -c xfce4-desktop -pn /desktop-icons/gravity -t int -s 2 
xfconf-query -c xfce4-desktop -pn /desktop-icons/icon-size -t int -s 42 
xfconf-query -c xfce4-desktop -pn /desktop-menu/show -t bool -s false 
xfconf-query -c xfce4-desktop -pn /desktop-menu/show-icons -t bool -s false 
xfconf-query -c xfce4-desktop -pn /desktop-icons/font-size -t double -s 10.000000
xfconf-query -c xfce4-keyboard-shortcuts -pn /commands/custom/"<Primary>l" -t string -s xfce4-appfinder
xfconf-query -c xfce4-keyboard-shortcuts -pn /xfwm4/custom/"<Alt>Tab" -t string -s cycle_windows_key 
xfconf-query -c xfce4-keyboard-shortcuts -pn /xfwm4/custom/"<Alt>q" -t string -s close_window_key
xfconf-query -c keyboards -pn /Default/Numlock -t bool -s true 
xfconf-query -c xfce4-appfinder -pn /always-center -t bool -s true 
xfconf-query -c xfce4-appfinder -pn /category-icon-size -t int -s 1 
xfconf-query -c xfce4-appfinder -pn /hide-category-pane -t bool -s true 
xfconf-query -c xfce4-appfinder -pn /icon-view -t bool -s true 
xfconf-query -c xfce4-appfinder -pn /item-icon-size -t int -s 5 
xfconf-query -c xfce4-appfinder -pn /last/pane-position -t int -s 180 
xfconf-query -c xfce4-appfinder -pn /last/window-height -t int -s 900 
xfconf-query -c xfce4-appfinder -pn /last/window-width -t int -s 1600 
xfconf-query -c xfce4-appfinder -pn /hide-window-decorations -t bool -s false
xfconf-query -c thunar -pn /misc-date-style -t string -s THUNAR_DATE_STYLE_YYYYMMDD 
xfconf-query -c thunar -pn /last-details-view-column-order -t string -s THUNAR_COLUMN_NAME,THUNAR_COLUMN_DATE_MODIFIED,THUNAR_COLUMN_SIZE,THUNAR_COLUMN_SIZE_IN_BYTES,THUNAR_COLUMN_TYPE,THUNAR_COLUMN_LOCATION,THUNAR_COLUMN_GROUP,THUNAR_COLUMN_MIME_TYPE,THUNAR_COLUMN_DATE_CREATED,THUNAR_COLUMN_OWNER,THUNAR_COLUMN_PERMISSIONS,THUNAR_COLUMN_DATE_ACCESSED,THUNAR_COLUMN_RECENCY,THUNAR_COLUMN_DATE_DELETED 
value="['nemo.dockitem', 'xfce4-appfinder.dockitem', 'firefox.dockitem', 'google-chrome.dockitem', 'transmission-gtk.dockitem', 'org.xfce.mousepad.dockitem', 'org.gnome.Calculator.dockitem', 'xfce4-screenshooter.dockitem', 'lazpaint.dockitem', 'mintinstall.dockitem', 'xfce4-terminal.dockitem', 'xfce-settings-manager.dockitem', 'gnome-system-monitor.dockitem', 'org.gnome.DiskUtility.dockitem', 'trash.dockitem']" 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ dock-items "$value" 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ theme MacOS_Plank-Theme 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ icon-size 36  
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ zoom-enabled true 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ zoom-percent 190 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ hide-mode none 
gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ auto-pinning true
gsettings set org.xfce.mousepad.preferences.view color-scheme 'classic'
gsettings set org.xfce.mousepad.preferences.view show-line-numbers true
gsettings set org.xfce.mousepad.preferences.view word-wrap true
gsettings set org.xfce.mousepad.preferences.window opening-mode 'window'
gsettings set org.xfce.mousepad.state.application enabled-plugins "['mousepad-plugin-gspell']"
gsettings set org.cinnamon.desktop.default-applications.terminal exec xfce4-terminal
xdg-mime default nemo.desktop inode/directory
captions="['none','none','none']" 
gsettings set org.nemo.icon-view captions "$captions" 
columns="['name', 'date_modified', 'size', 'type']" 
gsettings set org.nemo.list-view default-visible-columns "$columns" 
gsettings set org.nemo.preferences date-format 'iso' 
gsettings set org.nemo.preferences quick-renames-with-pause-in-between true 
gsettings set org.nemo.preferences show-home-icon-toolbar true 
gsettings set org.nemo.preferences show-reload-icon-toolbar true 
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitoreDP-1/workspace0/last-image -t string -s "$HOME/.local/share/backgrounds/Mac-Wallpapers/Aurora.jpg" 
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitoreDP-1/workspace0/image-style -t int -s 3
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitor0/workspace0/last-image -t string -s "$HOME/.local/share/backgrounds/Mac-Wallpapers/Aurora.jpg" 
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitor0/workspace0/image-style -t int -s 3
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitor1/workspace0/last-image -t string -s "$HOME/.local/share/backgrounds/Mac-Wallpapers/Aurora.jpg" 
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitor1/workspace0/image-style -t int -s 3
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitorVirtual1/workspace0/last-image -t string -s "$HOME/.local/share/backgrounds/Mac-Wallpapers/Aurora.jpg" 
xfconf-query -c xfce4-desktop -pn /backdrop/screen0/monitorVirtual1/workspace0/image-style -t int -s 3
#
# Countdown to reboot...
#
 clear
echo
echo "   All Done. Enjoy!"
 sleep 3
count=5
	while [ $count -gt 0 ]
 do
clear; echo; echo "   Rebooting in $count seconds."
   count=$(( $count -1 ))
 sleep 1 ; clear
done
#
# Fingers crossed that everything will work properly ;- )
#
reboot

exit
#
	else
 clear
echo
echo "   ***************************************************************"
echo "            Your current login session is $XDG_CURRENT_DESKTOP."
echo "      You MUST be logged into an XFCE session before continuing."
echo "   ***************************************************************"
echo

	fi

	while true; do
    read -p "   Are you ready to be logged out now? y/n " yn
echo
    case $yn in
	[Yy]* ) cinnamon-session-quit --logout; clear; echo; source do-second.sh; exit;;
        [Nn]* ) clear; echo; echo "   Okay. We'll try this again when you're ready."; echo; sleep 4; exit;;
        * ) echo "   Please select either Yes or No."; echo
    esac
done
#
